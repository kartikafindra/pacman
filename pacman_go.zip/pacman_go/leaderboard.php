<!DOCTYPE html>
<html>

<head>
    <title>Leaderboard</title>
    <!-- Load file CSS Bootstrap offline -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <br>
        <h4>Leaderboard</h4>
        <?php

    include "koneksi.php";

    
?>


        <table class="table table-bordered table-hover">
            <br>
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Nickname</th>
                    <th>Cheer</th>
                    <th>Jeer</th>

                </tr>
            </thead>
            <?php
        include "koneksi.php";
        $sql="select nickname,sum(cheer) as cheer,sum(jeer) as jeer from polling_table group by nickname order by cheer desc";

        $hasil=mysqli_query($kon,$sql);
        $no=0;
        while ($data = mysqli_fetch_array($hasil)) {
            $no++;

            ?>
            <tbody>
                <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $data["nickname"]; ?></td>
                    <td><?php echo $data["cheer"];   ?></td>
                    <td><?php echo $data["jeer"];   ?></td>
                </tr>
            </tbody>
            <?php
        }
        ?>
        </table>

    </div>
</body>

</html>